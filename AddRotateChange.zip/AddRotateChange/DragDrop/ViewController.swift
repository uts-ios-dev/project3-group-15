//
//  ViewController.swift
//  DragDrop
//
//  Created by Maggie Liuzzi on 21/5/18.
//  Copyright © 2018 Maggie Liuzzi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var sticker1: UIButton!
    @IBOutlet weak var sticker2: UIButton!
    @IBOutlet weak var sticker3: UIButton!
    
    /*
    var location = CGPoint(x: 0, y: 0)
     
    override func touchesBegan(_ touches: Set<UITouch>!, with event: UIEvent!) {
        let touch : UITouch! = touches.anyObject() as UITouch // or touches.first // Try this
        location = touch.location(in: self.view)
        sticker3.center = location
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch : UITouch! = touches.anyObject() as UITouch
        location = touch.location(in: self.view)
        sticker3.center = location
    }
    */
    
    public var screenWidth: Double {
        return Double(UIScreen.main.bounds.width)
    }
    public var screenHeight: Double {
        return Double(UIScreen.main.bounds.height)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // sticker3.center = CGPointMake(160, 330)
        
        /*
        self.scrollView.minimumZoomScale = 1.0
        self.scrollView.maximumZoomScale = 6.0
        scrollView.delegate = self
        */
    }

    func draggedSticker(selectedSticker: String) {
        let stickerTemplate = UIButton(frame: CGRect(x: (screenWidth * 0.4 + Double(arc4random_uniform(UInt32(screenWidth * 0.4)))), y: (screenWidth * 0.2 + Double(arc4random_uniform(UInt32(screenHeight * 0.7)))), width: 72.0, height: 72.0))
        
        if selectedSticker == "1" {
            let image = UIImage(named: "sticker1") as UIImage?
            stickerTemplate.setImage(image, for: UIControlState.normal)
            stickerTemplate.addTarget(self, action: #selector(editSticker1(_: )), for: UIControlEvents.touchUpInside) // allTouchEvents
        }
        if selectedSticker == "2" {
            let image = UIImage(named: "sticker2") as UIImage?
            stickerTemplate.setImage(image, for: UIControlState.normal)
            stickerTemplate.addTarget(self, action: #selector(editSticker2(_: )), for: UIControlEvents.touchUpInside)
        }
        if selectedSticker == "3" {
            let image = UIImage(named: "sticker3") as UIImage?
            stickerTemplate.setImage(image, for: UIControlState.normal)
            stickerTemplate.addTarget(self, action: #selector(editSticker3(_: )), for: UIControlEvents.touchUpInside)
        }
        self.view.addSubview(stickerTemplate)
    }
    
    @IBAction func sticker1(_ sender: Any) {
        // sticker1.isHidden = true
        draggedSticker(selectedSticker: "1")
    }
    @IBAction func sticker2(_ sender: Any) {
        // sticker2.isHidden = true
        draggedSticker(selectedSticker: "2")
    }
    @IBAction func sticker3(_ sender: Any) {
        draggedSticker(selectedSticker: "3")
    }
    
    @objc func editSticker1(_ sender: Any) {
        // (sender as! UIButton).transform = CGAffineTransform(rotationAngle: CGFloat.pi / 2) // rotates 90 degrees to the left
        (sender as! UIButton).transform = CGAffineTransform(rotationAngle: CGFloat.pi / 3)
    }
    
    @objc func editSticker2(_ sender: Any) {
        let image = UIImage(named: "sticker1") as UIImage?
        (sender as AnyObject).setImage(image, for: UIControlState.normal)
    }
    
    @objc func editSticker3(_ sender: Any) {
        /*
        (sender as! UIButton).animate(withDuration: 1, animations: {
            (sender as! UIButton).transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        }) { (finished) in
            UIView.animate(withDuration: 1, animations: {
                (sender as! UIButton).transform = CGAffineTransform.identity
            })
        }
        */
    }

    /*
    func viewForZoomingInScrollView(scrollView: UIScrollVIew) -> UIView? {
        return self.sticker3
    }
     */
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

